
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <title><?php bloginfo('name'); ?></title>
  <!-- Bootstrap core CSS -->
  <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
      
  <?php wp_head(); ?>
</head>
<body>
  <div class="blog-masthead">
    <div class="container">
      <nav class="blog-nav">
        <?php
          wp_nav_menu( array(
              'menu'              => 'primary',
              'theme_location'    => 'primary',
              'depth'             => 2,
              'container'         => 'div',
              'container_class'   => 'collapse navbar-collapse',
              'container_id'      => 'bs-example-navbar-collapse-1',
              'menu_class'        => 'nav navbar-nav',
              'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
              'walker'            => new WP_Bootstrap_Navwalker())
          );
      ?>
      </nav>
    </div>
  </div>
  <section class="showcase">
    <div class="container">
      <h1>Mount Everest Travel Agency</h1>
      <h4>Discover the Beauty of the World</h4>
      
    </div>
  </section>
  <section class="boxes">
    <div class="container">
          <div class="row">
            <div class="col-lg-9 col -md-9 col -s-9">
              <div class="row">
                <div class="col-lg-11 col-md-8 col is-11" id="tex">
                  <h1>Explore the World </h1>
                    <p> Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. 
                    </p>
                </div>
                
            </div>
            
      <div class="row">
       
          <div class="col-lg-4 col-md-4 col-s-12  ">
                    <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/malaysia.jpg" alt="image">
                        <h4>Malaysia</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-s-12  ">
          <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/moscow.jpg" alt="image">
                        <h4>Moscow</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-s-12  ">
          <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/jordan.jpg" alt="image">
                        <h4>Jordan</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div>

      <div class="row">
       
          <div class="col-lg-4 col-md-4 col-s-12  ">
                    <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/sudan2.jpg" alt="image">
                        <h4>Sudan</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-s-12  ">
          <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/sydney.jpg" alt="image">
                        <h4>Sydney</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-s-12  ">
          <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/georgia.jpg" alt="image">
                        <h4>Georgia</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div>

      <div class="row">
       
          <div class="col-lg-4 col-md-4 col-s-12  ">
                    <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/singapore.jpg" alt="image">
                        <h4>Singapore</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-s-12  ">
          <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/safari.jpg" alt="image">
                        <h4>Kenya</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-s-12  ">
          <div class="box">
                        <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/salvador.jpg" alt="image">
                        <h4>Salvador</h4>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div>
    </div>

        <div class="col-lg-3 col-md-3 col-s-12">
                    <?php
                          if(is_active_sidebar('sidebar')):
                         dynamic_sidebar('sidebar');
                         endif;  
                    ?>
                </div>  
      </div>


    </div>
  </section>
<?php get_footer(); ?>