<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_cr12_maha_mahmoud_traveler' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '}GMam}XGd:&j*@w&?zT(qo5OQmGMC4%is|GB4-~7UVL=wYK|>`Ra+lST?@:f(ftI' );
define( 'SECURE_AUTH_KEY',  'MUV7qczIR:GPYn;`53H56[!5q|`a:@`;WNSPT1@GVB(xMlmej{KIE+)h)mA6<_JI' );
define( 'LOGGED_IN_KEY',    '^ RCzCbzOgoYZJ+{W`HzM]bok~kMk,`9!/Ec~/J&H<75r/BI;Wwt75q?<zxatVVr' );
define( 'NONCE_KEY',        'L&E,*9WO27}55Cl1AUBPmvhFLJrjuNX0!/wR[V;FUy7SqNVm}fo{U&GfIBF? v_e' );
define( 'AUTH_SALT',        '?w/rc1,S02g^4l!d!PFn+}2YSXh8%qQ6s6vl`<P29?Agit;tDOl9Hf_4`n5F;Rj8' );
define( 'SECURE_AUTH_SALT', 'Q<K(^cbV$ G>Hg|L*^4MA-DhysE<3wh^NuEcy{]D$V*F^6Ds)$ba/~QGkxPE<6dj' );
define( 'LOGGED_IN_SALT',   'y* 1,`,`Zh^<4?d3`6^-h5HH9pB^/7fy{%!gm&.VV#<A6)a|76?Q4`qoI XMhU~b' );
define( 'NONCE_SALT',       'DJNq@ySC)3~X]@D$ZfPv kd9C!B/mJBSRb,7t5tfF*XOnV,d(C,}r3 y Qz9M4j|' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
